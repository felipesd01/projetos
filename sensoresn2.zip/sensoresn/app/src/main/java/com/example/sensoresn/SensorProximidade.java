package com.example.sensoresn;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SensorProximidade extends AppCompatActivity  implements SensorEventListener {
    private TextView resultado;
    private Sensor proximidade;
    private SensorManager medir;
    private Button btnVoltar, btnLuminosidade;


    @SuppressLint("ServiceCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor_proximidade);

        medir = (SensorManager) this.getSystemService(SEARCH_SERVICE);
        proximidade = medir.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        resultado = findViewById(R.id.resultado);
        btnVoltar =  findViewById(R.id.btnVoltar);
        btnLuminosidade = findViewById(R.id.btnLuminosidade);

        btnLuminosidade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirLuminosidade();
            }
        });

        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirVoltar();
            }
        });

    }

    @Override
    protected void onResume() {
        medir.registerListener(this, proximidade, SensorManager.SENSOR_DELAY_NORMAL);
        super.onResume();
    }

    @Override
    protected void onPause() {
        medir.unregisterListener(this,proximidade);
        super.onPause();
    }

    public void abrirLuminosidade(){
        Intent janela = new Intent(this,SensorLuminosidade.class);
        startActivity(janela);
    }

    public void abrirVoltar(){
        Intent janela = new Intent(this,MainActivity.class);
        startActivity(janela);
    }

    public void onSensorChanged(SensorEvent event) {
        if(event.values[0] == 0)
        {
            getWindow().getDecorView().setBackgroundColor(Color.MAGENTA);
            resultado.setText("PRÓXIMO");
        }

            getWindow().getDecorView().setBackgroundColor(Color.CYAN);
            resultado.setText("AFASTADO");

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}