package com.example.guardioensdagalaxia;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.TextView;

public class Escolha extends AppCompatActivity {

    private TextView resposta;
    private Button btnTeaser, btnMusica;
    private WebView imagem2;


    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_escolha);

        resposta = findViewById(R.id.resposta);
        imagem2 = findViewById(R.id.imagem2);
        btnMusica = findViewById(R.id.btnmusica);
        btnTeaser = findViewById(R.id.btnTeaser);


        String recebe = getIntent().getStringExtra("dados");
        resposta.setText(recebe);

        WebSettings gif = imagem2.getSettings();
        String caminho = "file:android_assets/imagem2.gif";
        imagem2.loadUrl(caminho);

        btnTeaser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirTeaser();
            }
        });

        btnMusica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirMusica();
            }
        });

    }
        public void abrirTeaser () {
            Intent janelat = new Intent(this,Teaser.class);
            startActivity(janelat);
        }
        public void abrirMusica (){
            Intent janelas = new Intent(this,Som.class);
            startActivity(janelas);
        }
    
}